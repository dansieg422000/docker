#!/usr/bin/env bash

# SSH Agent Forward check.
# Verifies the SSH Agent is set and correctly forwarding
if [ -z "$SSH_AUTH_SOCK" ]; then
    echo "SSH: Failed to detect SSH_AUTH_SOCK. SSH Agent Forwarding might not be working."
fi

# Perform exec into Docker container
sudo docker-compose -f docker-compose.$1.yml exec $2 sh -c "export TERM=${TERM}; $3"