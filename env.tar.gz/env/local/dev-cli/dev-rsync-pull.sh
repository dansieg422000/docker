#!/usr/bin/env bash

# Command: Rsync Pull
# Synchronise select VM directories with local
#
register_command "rsync-pull" "cmd_rsync-pull" "RSYNC: Pull assets from VM to local machine"
function cmd_rsync-pull ()
{
    msg "Synchronising from VM into Local ..."

    type ssh >/dev/null 2>&1 || { echo >&2 "ERROR: SSH must be available from the command line."; exit 1; }

    vagrant_ssh-config-create

    # List of select items to copy
    file_paths=(
        "app/bootstrap.php.cache"
        "app/cache/*"
        "app/files/*"
        "app/runtime/*"
        "vendor/*"
        "web/*"
    )
    for file_path in ${file_paths[@]}
    do
        dir_path=$(dirname "${file_path}")
        echo " <- \"${file_path}\"";

        # SSH and pipe each directory as a compressed file
        # Remarkably, this is faster than using rsync.
        mkdir -p www/tms/${dir_path}
        vagrant_ssh "cd /var/www/tms/; tar -zcf - ${file_path}" | tar -C ./www/tms/ -xzf -
    done

    vagrant_ssh-config-remove

    msg "Rsync pull complete. Local updated." success

    # sync remote to local
    #rsync -zaP --delete --exclude .git --exclude app --exclude node_modules --exclude src -e 'ssh -F .vagrant/ssh-config' default:/var/www/tms/* ./www/tms2/
}
