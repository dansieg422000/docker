#!/usr/bin/env bash
#
# Shell to specific containers
#

#
# General shell tool
#
register_command "v" "cmd_shell" "Shell into the host VM"
function cmd_shell()
{
    msg "Connecting to Host VM ..."

    vagrant_ssh-host 'bash -li'
}

#
# VM
#
register_command "shell" "cmd_shell-vagrant" "Shell into a specific docker container"
function cmd_shell-vagrant()
{
    if [ "$1" == "" ] || [ "$2" == "" ]; then
        msg "You must specify both a Group and a Container name to shell into (eg. 'shell app app-tms')." error
        exit 1
    fi

    msg "Trying to connect to Container '$2' inside Group '$1' ..." heading

    vagrant_ssh-container "$1" "$2" "/bin/sh"
}

#
# TMS
#
register_command "tms" "cmd_shell-tms" "Shell into the TMS webserver"
function cmd_shell-tms()
{
    msg "Connecting to TMS Webserver ..."

    vagrant_ssh-container "app" "app-tms" "'cd /var/www/tms; exec sudo -u www-data -s bash'"
}

#
# LMS
#
register_command "lms" "cmd_shell-lms" "Shell into the LMS webserver"
function cmd_shell-lms()
{
    msg "Connecting to LMS Webserver ..."

    vagrant_ssh-container "app" "app-lms" "'cd /var/www/tms; exec sudo -u www-data -s bash'"
}