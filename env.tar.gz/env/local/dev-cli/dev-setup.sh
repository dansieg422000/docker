#!/usr/bin/env bash

#
# Auto-Setup
# This thing tried to check out code and stuff, and start as many services into a working state as possible.
#
register_command "setup" "cmd_setup" "Run auto-setup process for the VM"
function cmd_setup()
{
    setup_intro

    # Run SSH fixes before doing preflight
    vagrant_fix-pageant

    setup_preflight_checks

    setup_provision_host

    setup_provision_tms

    setup_complete
}

# Setup Intro
#
function setup_intro()
{
    # Logo
    cmd_logo

    cat << "EOF"
     - - - - - - - - - - - - - - - - - - - - - - - - - -
EOF
    sleep 2

    # Prompt user about what's gunna happen
    # Font: http://patorjk.com/software/taag/#p=display&f=JS%20Stick
    cat << "EOF"
                  ___  __      __   ___ ___       __
         /\  |  |  |  /  \    /__` |__   |  |  | |__)
        /--\ \__/  |  \__/    .__/ |___  |  \__/ |

EOF

    cat << "EOF"
     - - - - - - - - - - - - - - - - - - - - - - - - - -
EOF
    sleep 2

    echo ""
    echo "This will attempt to install and set up the TMS automagically."
    echo ""
    echo "WARNING: This may delete things from within this directory!"
    echo "         Be sure to back up anything you don't want to lose."
    echo ""
    echo "WARNING: This is still a beta process, it's rarely flawless and may bail out with errors for no reason!"
    echo "         Always keep a senior developer on stand-by."
    echo ""
    echo ""
    sleep 2

    msg_clear; echo '  (.__.)       '; sleep .25;
    msg_clear; echo '   (/.__.)/    '; sleep .25;
    msg_clear; echo '    (/.__.)/   '; sleep .25;
    msg_clear; echo '     (.__.)    '; sleep .25;
    msg_clear; echo '   \(.__.\)    '; sleep .25;
    msg_clear; echo '  \(.__.\)     '; sleep .25;
    msg_clear; echo '  (.__.)       '; sleep 1;
    msg_clear; echo '  (.__.) -- woo yeah'; sleep 2;
    msg_clear

    echo "Press [Enter] to continue, or [Ctrl+C] to abort."
    read
}

# Pre-flight checks for the current environment
#
function setup_preflight_checks()
{
    msg "Running pre-flight checks on your environment ..." heading

    # Check commands
    type vagrant >/dev/null 2>&1 || { msg "Command 'vagrant' is required but could not be found." error; exit 1; }
    type ssh >/dev/null 2>&1 || { msg "Command 'ssh' is required but could not be found." error; exit 1; }

    # SSH Agent checks

    # Check SSH Agent
    if [[ "$(ssh-add -l 2>&1)" == *"agent has no ident"* ]]; then
        msg "SSH-FORWARDING: There are no keys registered with the running SSH-Agent!" error
        msg "Use 'ssh-add <keyfile>' (linux) or Pageant (windows) to register a key!"
        exit 1

    # Verify an SSH Agent is running. If not, throw a warning.
    elif [[ "$(ssh-add -l 2>&1)" == *"rror connecting to agent"* ]]; then
        msg "SSH-FORWARDING: There is no ssh-agent running! Key forwarding will not work." error
        msg "Linux: Use 'exec \$(ssh-agent)' to start the ssh agent."
        msg "Windows: Install 'ssh-pageant' and re-run this script."
        exit 1
    else
        echo "SSH Agent Forwarding: OK"
    fi

    # SSH: Check bitbucket login
    # Users need to set up SSH keys.
    if [[ "$(ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no git@bitbucket.org 2>&1)" == *"logged in as"* ]]; then
        echo "SSH Authentication: OK"
    else
        msg "SSH Authentication: A key was found and registered, but you do not have permission to login with git@bitbucket.org." error
        echo "Check your account on bitbucket.org, and ensure you have an SSH key set up."
        echo "If you have more than one key in use, make sure the right one is used when connecting to bitbucket.org"
        echo "See ssh documentation for '~/.ssh/config' and 'IdentityFile'."
        exit 1
    fi

    # Amazon: Check S3 login
    # External locations may not ben whitelisted for AWS S3 access
    # FIXME: This resource might change
    if [ "$(curl -s -o /dev/null -w %{http_code} https://s3-ap-southeast-2.amazonaws.com/repo.elmo.elmotalent.com.au/ckfinder-2.3.1.zip 2>&1)" == "200" ]; then
        echo "AWS S3 Authentication: OK"
    else
        msg "AWS S3 Authentication: Trying to access resources on S3 responded with 403 Forbidden." error
        echo "Your location must not be on the whitelist. Please contact someone in ops and get your location added to the AWS S3 Whitelist."
        echo "Resource tried: https://s3-ap-southeast-2.amazonaws.com/repo.elmo.elmotalent.com.au/ckfinder-2.3.1.zip"
        exit 1
    fi

    # Check TMS Settings

    if [[ ! $Config_repo_tms_upstream ]]; then
        # Health check: Upstream repo
        msg "Code Repository Settings: Upstream repository not defined. Please set repo_tms_upstream in config.yml" error
        exit 1

    elif [[ ! $Config_repo_tms_origin ]]; then
        # Health check: Origin repo
        msg "Code Repository Settings: Origin repository not defined. Please set repo_tms_origin in config.yml" error
        exit 1
    else
        echo "Code Repository Settings: OK"
    fi
}

# Provision the Host OS
#
function setup_provision_host()
{
    msg "Provisioning docker host VM ..." heading

    # Skip if VM is already running
    if vagrant status --machine-readable 2>&1 | grep state,running > /dev/null; then
        msg "Vagrant host is already running and is assumed to be provisioned. Provisioning stage will be skipped." alert
        sleep 4
        return
    fi

    # standard start should cause provision
    cmd_vagrant-up
}

# Provision the TMS
#
function setup_provision_tms()
{
    msg "Provisioning TMS Application ..." heading

    # TMS: Pre
    setup_tms_pre

    # CMD: Rsync INTO vm (code!)
    cmd_rsync

    # TMS: Post
    setup_tms_post

    # CMD: Rsync FROM vm (vendors etc)
    cmd_rsync-pull
}

# TMS: Code checkout
#
function setup_tms_pre()
{

    # Check out code if not exist
    if [[ -f  "www/tms/composer.json" ]]; then

        msg "TMS code is already checked out in /www/tms. TMS Code checkout will be skipped." alert
        sleep 5
        return
    fi

    # Msg: What doing
    msg "[TMS] Clearing any existing code ..." heading
    sleep 1

    # Clear and create code dirs
    cd www
    rm -rf tms

    msg "[TMS] Cloning repositories (shallow) ..." heading
    msg "using origin   '$Config_repo_tms_origin'"
    msg "using upstream '$Config_repo_tms_upstream'"

    # Clone Origin
    git clone $Config_repo_tms_origin tms --progress --depth=1
    cd tms

    # Add Upstream
    git remote add upstream $Config_repo_tms_upstream

    # Developer branch hijack
    if [[ ! -z $Config_repo_branch ]]; then

        msg "[TMS] Checking out branch '$Config_repo_branch' ..." heading

        git fetch upstream $Config_repo_branch --depth=1
        git checkout -b $Config_repo_branch --track upstream/$Config_repo_branch
    else
       msg "[TMS] Checking out branch 'master' ..." heading
       git checkout master
    fi

    # Check for dev script; issue alert on missing
    if [ -f dev.sh ]; then
        msg "[TMS] Setting up local git hooks ..." heading\

        # Set up git on this end
        chmod +x dev.sh
        ./dev.sh setup-git

        # re-checkout branch to ensure the hooks fire
        git checkout
    fi

    return
}

#
# Post-Install setup for TMS
# - Run the auto-setup inside the TMS container
function setup_tms_post()
{
    msg "[TMS] Executing TMS setup script ..." heading

    # TMS Setup
    vagrant_ssh-container app app-tms "'exec sudo -u www-data -s \"bash -c /home/www-data/setup.sh\"'"
}

# Setup Complete output
#
function setup_complete()
{
    msg "Setup complete!" success

    # Open browser if possible, or just tell the user about the address.
    if [ "$(type open 2>&1 /dev/null)" ]; then
        open "http://local.elmotalent.com.au"
    elif [ "$(type explorer 2>&1 /dev/null)" ]; then
        explorer "http://local.elmotalent.com.au"
    else
        msg "Browse to http://local.elmotalent.com.au" info
    fi;
}
