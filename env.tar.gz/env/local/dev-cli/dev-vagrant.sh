#!/usr/bin/env bash

register_command "up" "cmd_vagrant-up" "Start the VM"
register_command "start" "cmd_vagrant-up" "" # Alias
register_command "resume" "cmd_vagrant-up" "" # Alias
register_command "unpause" "cmd_vagrant-up" "" # Alias
function cmd_vagrant-up()
{
    msg "Starting the VM ..." heading

    vagrant up

    msg "VM Ready!" success;
}

register_command "down" "cmd_vagrant-halt" "Stop the VM"
register_command "stop" "cmd_vagrant-halt" "" # Alias
register_command "halt" "cmd_vagrant-halt" "" # Alias
function cmd_vagrant-halt()
{
    msg "Stopping the VM ..." heading

    vagrant halt
    vagrant_ssh-config-remove

    msg "VM Stopped." success;
}

register_command "pause" "cmd_vagrant-pause" "Pause the VM"
register_command "suspend" "cmd_vagrant-pause" "" # Alias
function cmd_vagrant-pause()
{
    msg "Pausing the VM ..." heading

    vagrant suspend

    msg "VM Paused." success;
}

register_command "top" "cmd_vagrant-debug-top" "VM Debug: Process monitor"
function cmd_vagrant-debug-top()
{
    msg "Connecting to VM and starting top ..."

    vagrant_ssh-host "sudo htop"
}

register_command "net" "cmd_vagrant-debug-net" "VM Debug: Network packet monitor"
function cmd_vagrant-debug-net()
{
    msg "Connecting to VM and starting iptraf..."

    vagrant_ssh-host "sudo iptraf"
}
