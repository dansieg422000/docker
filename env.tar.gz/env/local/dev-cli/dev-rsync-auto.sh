#!/usr/bin/env bash

register_command "rsync-auto" "cmd_rsync-auto" "RSYNC: Watch and sync from local to VM"
function cmd_rsync-auto()
{
    msg "Starting code synchronisation watcher ...";
    vagrant rsync-auto

    msg "Rsync watch ceased." error
}