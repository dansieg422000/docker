#!/usr/bin/env bash

function load_config()
{

    # Health check: Config file is required
    if [[ ! -f "config.yml" ]]; then
        msg "Copy config.dist.yml to config.yml then change the settings!" error
        exit 1
    fi

    # Parse YML
    eval $(YamlParse__parse "config.yml" "Config_")
}