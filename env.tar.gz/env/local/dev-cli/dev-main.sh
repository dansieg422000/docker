#!/usr/bin/env bash
#
# Main entry-point for Dev script
#

# Dependency checks
type git >/dev/null 2>&1 || { echo >&2 "ERROR: Git must be available from the command line."; exit 1; }
type vagrant >/dev/null 2>&1 || { echo >&2 "ERROR: Vagrant must be available from the command line."; exit 1; }

# Bash version check. Must be > 4.0
if [ "$(printf "3.0.0\n$BASH_VERSION" | sort -V | head -n1)" == "$BASH_VERSION" ]; then
    echo >&2 "ERROR: Bash must be version 3.0 or greater. Try updating bash."; exit 1;
fi

# Fail on any error
set -e

# Get CWD
CWD="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Includes: Lib
source "$CWD/lib-util.sh"
source "$CWD/lib-vagrant.sh"
source "$CWD/lib-yaml.sh"

# Includes: Actions
source "$CWD/dev-upgrade.sh"
source "$CWD/dev-config.sh"
source "$CWD/dev-vagrant.sh"
source "$CWD/dev-setup.sh"
source "$CWD/dev-rsync.sh"
source "$CWD/dev-rsync-auto.sh"
source "$CWD/dev-rsync-pull.sh"
source "$CWD/dev-backup.sh"
source "$CWD/dev-shell.sh"
source "$CWD/dev-docker-registry.sh"

# Command
# Main Entry
#
function cmd_main()
{
    # Load the config file
    load_config

    # Resolve arguments
    ACTION=${1:-help}
    ARGS="${@:2}"

    match=0
    for cmd in "${!elmo_commands[@]}"
    do
        # Matches the requested action?
        if [ "$cmd" = "$ACTION" ]; then
            match+=1
            ${elmo_commands[$cmd]} $ARGS
        fi
    done

    if [ "$match" -eq 0 ]; then
        cmd_help
    fi
}

#
# Happy Logo
#
cmd_logo ()
{
    # VM Version
    vm_version="$(git describe)"
    vm_branch="$(git rev-parse --abbrev-ref HEAD)"
#    vb_vers="$(vboxmanage --version)"
    vg_vers="$(vagrant --version)"

#----------------------------------------------------------------------------80
    cat << EOF
     ___ _    __  __  ___    ___           __   ____  __
    | __| |  |  \/  |/ _ \  |   \ _____ __ \ \ / /  \/  |
    | _|| |__| |\/| | (_) | | |) / -_) V /  \ V /| |\/| |
    |___|____|_|  |_|\___/  |___/\___|\_/    \_/ |_|  |_|
        $vm_branch $vm_version on $vg_vers

EOF
} # ' <-Fix quote parse bug

#
# Show help dialog
#
register_command "help" "cmd_help" "Show this help dialog"
cmd_help ()
{

    # show logo
    cmd_logo

    # show command list
    command_category "VM Control"
    command_show up
    command_show down
    command_show pause

    command_category "Shell Access"
    command_show v
    command_show tms
    command_show lms
    command_show shell

    command_category "Tools"
    command_show setup
    command_show rsync
    command_show rsync-auto
    command_show rsync-pull
    command_show top
    command_show net

    command_category "Disaster Recovery"
    command_show backup
    command_show restore
}

# Start Main
cmd_main $@;