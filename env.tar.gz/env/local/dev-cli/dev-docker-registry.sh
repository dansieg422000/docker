#!/usr/bin/env bash
#
# Super-secret commands for creating a Docker Registry
#

#
# TMS
#
register_command "registry-create" "cmd_registry-create" "Create a Docker Registry on this machine."
function cmd_registry-create()
{
    msg "Creating a Docker Registry" heading

    # FIXME: Registry doesn't like to not be SSL, and doesn't like invalid SSL, so this doesk work with self-signed certs right now.
    msg "Not correctly implemented: Does not like to use self-signed certs" error
    exit 1;


    type cmd >/dev/null 2>&1 || { echo >&2 "ERROR: This command is only designed for a Windows system right now."; exit 1; }

    if [ ! "$(type docker 2>&1 /dev/null)" ]; then
        msg "Downloading Docker ..."
        sleep 1

        url="https://download.docker.com/win/stable/Docker%20for%20Windows%20Installer.exe"
        powershell Invoke-WebRequest $url -OutFile 'c:\windows\temp\docker-installer.exe' -UseBasicParsing

        msg "Installing Docker ..."

        powershell "Invoke-Command -ScriptBlock {
            Start-Process c:\windows\temp\docker-installer.exe -Wait
        }"
    else
        path=$(which docker)
        msg "Docker already installed at $path. Moving on."
    fi


    if [ "$(docker-machine active)" == "" ]; then
        msg "Setting up a docker-machine (called 'box') ..."
        sleep 1

        # Box creation
        docker-machine create docker-box

        # Env vars
        eval $(docker-machine.exe env box --shell=bash)
    else
        msg "docker-machine exists. Moving on."
    fi

    msg "Starting Registry ..."

    # Set up the registry
    # FIXME: Windows Docker Volumes do NOT support mapped disks. You can only use DIRECT paths or you get empty dirs.
    # FIXME: cygwin does fun things with paths: if it's not the direct "/c/" type path, it won't work! This regex fudges bad paths
    mnt=$(cygpath -a -u $PWD/env/certs | sed -e 's/^\/cygdrive//')

    powershell docker run \
        -d \
        --restart=always \
        --name registry \
        --mount type=bind,source=$mnt,target=/certs \
        -it \
        -e REGISTRY_HTTP_ADDR=0.0.0.0:443 \
        -e REGISTRY_HTTP_TLS_CERTIFICATE=/certs/registry.cert \
        -e REGISTRY_HTTP_TLS_KEY=/certs/registry.key \
        -p 443:443 \
        registry:2

    hostname=$(hostname)
    msg "Docker Registry now available at '$hostname:5000'." success
}