#!/usr/bin/env bash
#
# Environment-related hacks
#

# Vagrant Util
# SSH into Vagrant itself
function vagrant_ssh-host()
{
    # Shell into Vagrant box
    # We pass along $TERM so the internal term works correctly
    vagrant_fix-pageant
    vagrant ssh -c "TERM=${TERM}; $*"
}

# Vagrant Util
# SSH into vagrant, and the connect onto a specific container
function vagrant_ssh-container()
{
    vagrant_fix-pageant
    vagrant_ssh-host " ~/sub-shell.sh $*"
}

# Vagrant Util
# Use SSH
function vagrant_ssh()
{
    vagrant_fix-pageant
    vagrant_ssh-config-create
    ssh -A -F .vagrant/ssh-config default "$@"
}


# Vagrant Util
# Create the Vagrant SSH Config if it doesn't exist
#
function vagrant_ssh-config-create()
{
    # When not exists
    if [ ! -f ".vagrant/ssh-config" ]; then
        vagrant ssh-config > .vagrant/ssh-config
    fi
}

# Vagrant Util
# Destroy the Vagrant SSH config if it exists
#
function vagrant_ssh-config-remove()
{

    # if exists
    if [ -f ".vagrant/ssh-config" ]; then
        rm -f ./vagrant/ssh-config
    fi
}


# Vagrant Util
# Pageant SSH Helper for windows
# Runs ssh-pageant when installed, which shares the SSH keys to Vagrant.
# Writes to $SSH_AUTH_SOCK which will be kept by the VM.
function vagrant_fix-pageant()
{

    # Only required for Windows
    if [ "$(type cmd 2>&1 /dev/null)" ]; then
        # Must have Pageant
        if [ ! "$(type ssh-pageant 2>&1 /dev/null)" ]; then
            msg "Could not find ssh-pageant. You might have trouble checking out code." alert
            return
        fi

        # run pageant
        filename="/tmp/.ssh-pageant"
        eval $(ssh-pageant -r -a ${filename})
    fi

    # Verify an SSH Key is registered. If not, throw a warning.
    if [[ "$(ssh-add -l 2>&1)" == *"agent has no ident"* ]]; then
        msg "SSH-FORWARDING WARNING: There are no keys registered with the running SSH-Agent!" alert
        msg "Use 'ssh-add <keyfile>' (linux) or Pageant (windows) to register a key!"

    # Verify an SSH Agent is running. If not, throw a warning.
    elif [[ "$(ssh-add -l 2>&1)" == *"rror connecting to agent"* ]]; then
        msg "SSH-FORWARDING WARNING: There is no ssh-agent running! SSH key-forwarding will not work." alert
    fi

}
