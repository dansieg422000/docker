#!/usr/bin/env bash

register_command "rsync" "cmd_rsync" "RSYNC: Push local code to VM once"
function cmd_rsync()
{
    msg "Synchronising code to the VM from Local ..."
    vagrant rsync

    msg "Rsync complete. VM updated." success
}
