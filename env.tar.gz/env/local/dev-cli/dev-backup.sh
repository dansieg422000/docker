#!/usr/bin/env bash

#
# Backup VM
#
register_command "backup" "cmd_backup-backup" "Backup the VM to a zip file."
function cmd_backup-backup()
{
    msg "Attempting to back-up VM content ...";

    # Make backup dir
    mkdir backup

    # Execute
    vagrant_ssh-host "\
        sudo tar -czf /tmp/backup-www.tar.gz /var/www \
        && sudo tar -czf /tmp/backup-mysql.tar.gz /var/lib/mysql \
        && mv /tmp/backup-www.tar.gz /srv/backup \
        && mv /tmp/backup-mysql.tar.gz /srv/backup \
    "

    msg "Backup complete." success
}

#
# Restore backup
#
register_command "restore" "cmd_backup-restore" "Restore the VM from a zip file."
function cmd_backup-restore()
{
    msg "Attempting to restore VM backup ...";

    # Execute
    vagrant_ssh-host "\
        cp /srv/backup/backup-www.tar.gz /tmp \
        && sudo tar -xzf /tmp/backup-www.tar.gz -C / \
        && cp /srv/backup/backup-mysql.tar.gz /tmp \
        && sudo tar -xzf /tmp/backup-mysql.tar.gz -C / \
    "

    msg "Restore complete." success
}