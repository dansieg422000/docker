#!/usr/bin/env bash
#
# Utility Library for CLI things
#

# Var
# Container for commands
declare -A elmo_commands
declare -A elmo_commands_help

# Utility
# Command registration
#
function register_command()
{
    cli=$1  # Command-line name
    func=$2 # Bash script function
    desc=$3 # Description

    elmo_commands[$cli]=${func}
    elmo_commands_help[$cli]=${desc}

}

function command_category()
{
    printf "\n  %s\n" "$1"

    pad=$(printf '%0.1s' "-"{1..60}) # 60 dashes
    printf "  %*.*s\n" 0 ${#1} "$pad"
}

#
# List command
#
function command_show()
{
    cmd=$1

    desc=${elmo_commands_help[$cmd]}

    pad=$(printf '%0.1s' " "{1..60}) # 60 spaces
    padlength=16
    printf '%*.*s' 0 4 "$pad"
    printf '%s' "$cmd"
    printf '%*.*s' 0 $((padlength - ${#cmd})) "$pad"
    printf ' - %s\n' "$desc"
}

# Executes the given command, logging a colourful console message
#
function execute()
{
    command=${1}

    msg " \$ ${command} "
    command "$command"
}

#
# Display a pretty message
#
# Examples:
# msg "text" error
# msg "text" alert
# msg "text" success
# msg "text" heading
# msg "text"
#
function msg ()
{

    # Colors
    local C_MSG='\033[0;43;30m'     # black-on-yellow
    local C_SUCCESS='\033[0;42;30m'     # black-on-green
    local C_HEADING='\033[0;46;30m' # black-on-blue
    local C_ALERT='\033[0;41;30m'   # black-on-red
    local C_ERROR='\033[5;41;30m'   # black-on-red
    local C_NORM='\033[0m'          # reset

    # auto pad like a heading
    pad=1

    # Message is the first arg
    msg=$1

    # Pick style from second arg
    case "$2" in
        error*)
            printf "${C_ERROR}"
            msg="[ERROR] $msg"
            ;;
        alert*)
            printf "${C_ALERT}"
            msg="[ALERT] $msg"
            ;;
        success*)
            printf "${C_SUCCESS}"
            msg="[OK]    $msg"
            ;;
        heading*)
            printf "${C_HEADING}"
            msg="[INFO]  $msg"
            ;;
        *)
            pad=0
            printf ${C_MSG}
      esac

    # Base is 1 line
    msgs=( "$msg" )

    # Wrap with empty strings
    if [ "$pad" = 1 ]; then
        msgs=( " " "$msg" " " )
    fi

    # Each line
    for line_msg in "${msgs[@]}"
    do
        # Break line
        printf "\n "

        # Message
        printf " %s" "$line_msg"

        # Pad white space
        local padlength=$(tput cols)
        printf '%*.*s' $((padlength - ${#line_msg} - 10 )) $(printf '%0.1s' " "{1..200})
    done

    # Revert color
    printf "${C_NORM}\n\n"
}

# Clear X Previous lines
#
function msg_clear()
{
    lines=${1:-1}
    tput el

    for i in $(seq 1 $lines); do
        tput cuu 1
        tput el
    done
}