#!/usr/bin/env bash
#
# Upgrade VM from old version to new.
#

#
# VM: Upgrade
#
register_command "upgrade" "cmd_upgrade" "Upgrade the VM to the latest version."
function cmd_upgrade()
{

    msg "Upgrading the VM may be destructive!" alert
    sleep 5
    echo "Press [Enter] to continue, or [Ctrl+C] to abort."
    read

    # Halt VM
    cmd_vagrant-halt

    # Sleep before we do the dangerous bits
    sleep 5

    # Up VM with provision request
    msg "Re-provisioning VM ... " heading

    vagrant up --provision

    msg "VM upgrade complete!" success

}
