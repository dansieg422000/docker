# -*- mode: ruby -*-
# vi: set ft=ruby :

# Libs
require_relative './os.rb'

# VM Box
class ElmoVm

    #
    # Plugin dependencies
    #
    def self.installPlugins()

        plugin_missing = false
        plugin_deps = [
        ]

        # For each plugin
        plugin_deps.each do |plugin|
            if !Vagrant.has_plugin?(plugin)
                puts ""

                # Note: This can lead to some weird outputs. Ignore it.
                # Attempt to install plugin, or exit.
                system("vagrant plugin install " + plugin) || exit!
                plugin_missing = true
            end
        end

        # Exit if plugins were installed
        if plugin_missing
            puts "Dependencies installed. Restarting Vagrant..."
            exec('vagrant', *ARGV)
        end
    end

    #
    # Configure box
    #
    def self.configure(config, settings)

        # Run dependency checks
        self.installPlugins()

        # Box Config
        config.vm.hostname = settings["host_name"] ||= "tms"
        config.vm.box = "ubuntu/trusty64"

        # Box updates (skip / fix version)
        config.vm.box_check_update = false
#        config.vm.box_version = "20171213.0.2"

        # Virtualbox Options
        config.vm.provider :virtualbox do |vbox, override|
            vbox.name = settings["vm_name"] ||= "tms"
            vbox.customize ['modifyvm', :id, '--cpuexecutioncap', "90"]
            vbox.customize ['modifyvm', :id, '--memory', settings["memory"] ||= "4096"]
            vbox.customize ['modifyvm', :id, '--cpus', settings["cpus"] ||= "4"]
            vbox.customize ["modifyvm", :id, "--natdnsproxy1", "on"]
            vbox.customize ["modifyvm", :id, "--natdnshostresolver1", "off"]
        end
  
        # HostsManager
        config.hostmanager.enabled           = true
        config.hostmanager.manage_host       = true
        config.hostmanager.ignore_private_ip = false
        config.hostmanager.include_offline   = false
        config.hostmanager.aliases           = settings["host_aliases"] ||= "tms"
  
        # Network
        config.vm.network "public_network", use_dhcp_assigned_default_route: true
        config.vm.network(:private_network, ip: settings["ip"] ||= "192.168.56.101")

        # Shares Defaults
        mount_type = 'nfs'
        mount_options = ['rw','async','noatime','rsize=32768','wsize=32768','proto=tcp','nolock','vers=3','actimeo=1']

        # Shares for Windows
        if OS.windows?
            mount_type = ''
            mount_options = []
        end

        # Share: Docker environment configuration
        config.vm.synced_folder ".", "/srv", :type => mount_type, :mount_options => mount_options

        # Rsync Folders
        rsync_exclude_dirs = [
                "tms/.git",
                "tms/bin", "tms/node_modules", "tms/vendor",
                "tms/app/cache", "tms/app/files", "tms/app/img", "tms/app/logs", "tms/app/runtime", "tms/app/bootstrap.php.cache",
                "tms/web/theme", "tms/web/assets"
        ]

        # Share: Rsync uploads
        config.vm.synced_folder './www', '/var/www', id:'www',
            type: 'rsync',
            rsync__chown: true,
            owner: 'www-data', group: 'www-data',
            rsync__auto: true,
            rsync__verbose: false,
            rsync__args: ["--archive", "--delete", "-z", "--copy-links", "--recursive", "--protocol=25"],
            rsync__exclude: rsync_exclude_dirs

        # Provision
        config.vm.provision :shell, inline: "chmod +x /srv/env/host/vagrant-provision.sh"
        config.vm.provision :shell, inline: "/srv/env/host/vagrant-provision.sh provision"
        config.vm.provision :shell, inline: "/srv/env/host/vagrant-provision.sh", run:"always"

        # SSH Agent Forwarding. Enabled use of ssh key from Host OS.
        # Note: Windows requires ssh-pageant intermediary
        #       @see https://github.com/cuviper/ssh-pageant
        config.ssh.forward_agent = true

    end
end
