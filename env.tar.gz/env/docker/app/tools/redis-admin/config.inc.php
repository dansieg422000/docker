<?php

include 'config.sample.inc.php';

$admin_user = getenv('ADMIN_USER');
$admin_pass = getenv('ADMIN_PASS');

if (!empty($admin_user)) {
  $config['login'] = array(
    $admin_user => array(
      'password' => $admin_pass,
    ),
  );
}

$server_name = '';
$server_host = 'redis';
$server_port = 6379;

if (empty($server_name)) {
    $server_name = $server_host;
}

if (empty($server_port)) {
    $server_port = 6379;
}
$config['servers'] = [];
$config['servers'][] = array(
    'name' => $server_name,
    'host' => $server_host,
    'port' => $server_port,
    'filter' => '*',
);
