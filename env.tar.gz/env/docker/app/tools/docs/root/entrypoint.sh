#!/bin/sh

cd /docs
mkdocs serve --no-livereload --dev-addr 0.0.0.0:80