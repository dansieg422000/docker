#!/usr/bin/env bash
# Script to run inside the TMS container

# Load rc file which has custom functions
source /home/www-data/.bashrc

# add bitbucket.org to ssh known hosts
ssh-keyscan bitbucket.org >> ~/.ssh/known_hosts

# Die on errors
set -e

# Switch to www-data user
cd /var/www/tms

# Check correct user
if [ "$(whoami)" != "www-data" ]; then
    echo "Logged in as $(whoami) instead of www-data! Panic panic!";
    exit 1
fi

# Container can be set up in one of two ways:
# Preferably: The dev.sh script with its own setup-auto method
# Fallback: Classic hacks

if [ -f "/var/www/tms/dev.sh" ]; then

    # Use dev.sh script
    chmod +x dev.sh
    dev.sh setup-auto
    exit 0

else

    echo ""
    echo " !!"
    echo " !! Old branch detected: dev.sh script does not exist"
    echo " !! Falling back to classic setup process"
    echo " !!"
    echo ""
    sleep 1

    # Fallback to classic method
    app_docker_install

    # CompanyConfig cache fix
    mkdir -p /var/www/tms/app/runtime/dev
    mkdir -p /var/www/tms/app/runtime/test
    touch /var/www/tms/app/runtime/dev/config.json
    touch /var/www/tms/app/runtime/test/config.json

    # Ensure symfony cache is empty
    mkdir -p /var/www/tms/app/cache/
    rm -rf /var/www/tms/app/cache/*

    # Install parameters if not present
    if [ ! -f "/var/www/tms/app/config/parameters.yml" ]; then
        cp /var/www/tms/app/config/parameters.yml.dist /var/www/tms/app/config/parameters.yml
    fi

    # Composer go!
    composer install

    # Assets n stuff
    yarn install
    yarn gulp build
    /var/www/tms/app/console assetic:dump --env=dev
    /var/www/tms/app/console assetic:dump --env=test

    # JS Routes
    php app/console fos:js-routing:dump --env=test
fi
