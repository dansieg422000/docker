<?php

use Symfony\Component\ClassLoader\ApcClassLoader;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Debug\Debug;

$loader = require_once __DIR__ . '/../app/bootstrap.php.cache';

// Use APC for autoloading to improve performance.
// Change 'sf2' to a unique prefix in order to prevent cache key conflicts
// with other applications also using APC.
$elmoVersionFile = __DIR__.'/../elmo_version.txt';
$cacheKeyPrefix = false;
if (file_exists($elmoVersionFile)) {
    $cacheKeyPrefix = file_get_contents($elmoVersionFile);
}

if (empty($cacheKeyPrefix)) {
    $cacheKeyPrefix = 'epms';
}

define('ELMO_TMS_VERSION', $cacheKeyPrefix);

/* define web directory here */
define('WEB_DIRECTORY', __DIR__);

// Get server environment settings
$elmo_server_env = (string) getenv('ELMO_SERVER_ENV');      // Set by vhost
$elmo_server_debug = (bool) getenv('ELMO_SERVER_DEBUG');    // Set by dev

// Obtain and sanitize prefix
if(defined('CLI_SCRIPT')){
    $elmo_prefix = 'prod';
    if (isset($argv[1])) {
        $elmo_prefix = $argv[1];
    }
    if (isset($arguments['c'])) {
        $elmo_prefix = $arguments['c'];
    }
} else {
    $elmo_prefix = $_SERVER['HTTP_HOST'];
    if (isset($_ENV['HTTP_HOST'])){ // this is to support cronjobs on a per-host basis
        $elmo_prefix = $_ENV['HTTP_HOST'];
    }
    $elmo_prefix = explode('.', $elmo_prefix);
    $elmo_prefix = $elmo_prefix[0];
    $elmo_prefix = preg_replace("/\W/", "", $elmo_prefix);

    //subdomian cannot be prod
    if ($elmo_prefix == 'prod') {
        echo 'Invalid URL. Subdomain prefix cannot be "prod".';
    }

    // Subdomain can only be dev/test when environment is registered as test mode
    if (in_array($elmo_prefix, array('dev', 'test'))  ) {
        if ($elmo_server_env != $elmo_prefix) {
            echo sprintf('Invalid URL. Received %s expected %s.', $elmo_prefix, $elmo_server_env);
            exit;
        }
    }
}

// When not in developer mode, load the APC Class Cache.
if ($elmo_server_env !== 'dev') {
    $loader = new ApcClassLoader($cacheKeyPrefix, $loader);
    $loader->register(true);

    // Never use debug outside of Dev environment.
    $elmo_server_debug = false;
}

// If debug mode enabled, turn on debugging capabilities.
if ($elmo_server_debug === true) {
    Debug::enable();
}

// Load the Kernel
require_once __DIR__ . '/../app/AppKernel.php';
require_once __DIR__ . '/../app/AppCache.php';

// Load appropriate config
if (in_array($elmo_prefix, array('dev', 'test'))) {
    if (!file_exists(__DIR__ . '/../app/config/config_' .$elmo_prefix.'.yml')) {
        exit;
    }
} else {
    if (!file_exists(__DIR__ . '/../app/config/subdomains/config_' .$elmo_prefix.'.yml')) {
        exit;
    }
}

// Load Symfony Kernel
$kernel = new AppKernel($elmo_prefix, $elmo_server_debug);
$kernel->loadClassCache();

// Non-debug mode uses AppCache as reverse-proxy infront of Kernel.
if ($elmo_server_debug !== true) {
$kernel = new AppCache($kernel);
}

// Handle request/response cycle.
Request::enableHttpMethodParameterOverride();
$request = Request::createFromGlobals();
Request::setTrustedProxies(array($request->server->get('REMOTE_ADDR'), '127.0.0.1'));
$response = $kernel->handle($request);
$response->send();
$kernel->terminate($request, $response);
