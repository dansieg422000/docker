<?php

use Symfony\Component\DependencyInjection\ContainerBuilder;

/**
 * TMS Configuration when using a Docker host
 * Automatically aborts if the host is not Docker-based.
 *
 * @var $container ContainerBuilder
 */

// Not using docker? Don't run this config.
if (! getenv('APACHE_SERVERALIAS') == 'elmo_dev_vm') {
    return;
}

// MySQL
$container->setParameter('database_host', getenv('APP_DB_HOST'));
$container->setParameter('database_user_host', getenv('APP_DB_HOST'));
$container->setParameter('database_port', getenv('APP_DB_PORT'));
$container->setParameter('database_user', getenv('APP_DB_USERNAME'));
$container->setParameter('database_password', getenv('APP_DB_PASSWORD'));

// Redis
$container->setParameter('session_redis_server1', getenv('APP_REDIS_HOST1'));
$container->setParameter('session_redis_server2', getenv('APP_REDIS_HOST2'));

// SOLR
$container->setParameter('elmo_solr_host', getenv('APP_SOLR_HOST'));
$container->setParameter('elmo_solr_port', getenv('APP_SOLR_PORT'));

// Rabbit MQ (Queue)
$container->setParameter('elmo_queue_host', getenv('APP_QUEUE_HOST'));
$container->setParameter('elmo_queue_port', getenv('APP_QUEUE_PORT'));
$container->setParameter('elmo_queue_username', getenv('APP_QUEUE_USERNAME'));
$container->setParameter('elmo_queue_password', getenv('APP_QUEUE_PASSWORD'));

// Mail Catcher
$container->setParameter('mailer_host', getenv('APP_MAILER_HOST'));
$container->setParameter('mailer_port', getenv('APP_MAILER_PORT'));
$container->setParameter('mailer_user', getenv('APP_MAILER_USERNAME'));
$container->setParameter('mailer_password', getenv('APP_MAILER_PASSWORD'));
