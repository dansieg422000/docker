# Docker Solr for TMS

## UNTIL SOMEONE FIXES IT:

YOU NEED TO COPY THE `schema.xml` FILE FROM THE TMS

```\src\Elmo\SolrBundle\Resources\config\solr\schema.xml```

AND PLACE IT HERE:

```root\opt\solr\server\solr\configsets\elmo_tms\conf\schema.xml```

BEFORE BUILDING THE CONTAINER.