#!/usr/bin/env bash

# Fail on any error
set -e

# Var
# Container for commands
declare -A elmo_commands
declare -A elmo_commands_help

# Utility
# Command registration
#
function register_command()
{
    cli=$1  # Command-line name
    func=$2 # Bash script function
    desc=$3 # Description

    elmo_commands[$cli]=${func}
    elmo_commands_help[$cli]=${desc}

}

# Command
# Main Entry
#
function cmd_main()
{
    # Resolve arguments
    ACTION=${1:-help}
    ARGS="${@:2}"

    match=0
    for cmd in "${!elmo_commands[@]}"
    do
        # Matches the requested action?
        if [ "$cmd" = "$ACTION" ]; then
            match+=1
            ${elmo_commands[$cmd]} $ARGS
        fi
    done

    if [ "$match" -eq 0 ]; then
        cmd_help
    fi
}

#
# List command
#
function command_show()
{
    cmd=$1

    desc=${elmo_commands_help[$cmd]}

    pad=$(printf '%0.1s' " "{1..60}) # 60 spaces
    padlength=16
    printf '%*.*s' 0 4 "$pad"
    printf '%s' "$cmd"
    printf '%*.*s' 0 $((padlength - ${#cmd})) "$pad"
    printf ' - %s\n' "$desc"
}

# Executes the given command, logging a colourful console message
#
function execute()
{
    command=${1}

    msg " \$ ${command} "
    command "$command"
}

#
# Show help dialog
#
register_command "help" "cmd_help" "Show this help dialog"
cmd_help ()
{
    printf "\nDocker helper thingo\n"

    # show command list
    printf "\n  Service Control\n"
    command_show ps
    command_show ls
    command_show up
    command_show down
    printf "\n  Dev commands\n"
    command_show shell
    command_show rebuild
    command_show start-shell
    printf "\n  'I know what I'm doing' commands\n"
    command_show build-all
    command_show clean
    command_show clean-logs
    echo ""
}

# -------------------- Commands --------------------

#
# Group: Raise
#
register_command "ps" "cmd_ps" "Get the running state for all containers for all groups"
function cmd_ps()
{
    sudo docker ps -a --format 'table {{.ID}}\t{{.Names}}\t{{.Status}}\t{{.Size}}\t'
}

#
# Group: Start
#
register_command "up" "cmd_group_up" "Start a group of containers"
function cmd_group_up()
{
    if [ "$1" == "" ]; then
        msg "You must specify a group to start. Use the 'list' command to see available groups." error
        exit 1
    fi

    if [ ! -e "docker-compose.$1.yml" ]; then
        msg "Group '$1' does not exist. Use the 'list' command to see available groups." error
        exit 1
    fi

    msg "Starting group $1 ..."

    sudo docker-compose -f docker-compose.$1.yml up -d

    msg "Service Group $1 online." success
}

#
# Group: Stop
#
register_command "down" "cmd_group_down" "Stop a group of containers"
function cmd_group_down()
{
    if [ "$1" == "" ]; then
        msg "You must specify a group to stop. Use the 'list' command to see available groups." error
        exit 1
    fi

    msg "Stopping Service Group $1 ..." heading

    sudo docker-compose -f docker-compose.$1.yml stop

    msg "Service Group $1 offline." success
}

#
# Group: List
#
register_command "ls" "cmd_group_list" "List the available service groups."
function cmd_group_list()
{
    msg "Available Service Groups" heading
    find . -type f -name "docker-compose.*.yml" | awk -F'[.]' '{printf "  %s\n", $3}'
    echo ""
}

#
# Rebuild all containers
#
register_command "build-all" "cmd_build_all" "Build all containers"
function cmd_build_all()
{
    msg "Building all containers ..." heading
    sleep 1

    source build.sh

    msg "All containers built." success
}

#
# Rebuild one container
#
register_command "rebuild" "cmd_rebuild" "Rebuild a specific container"
function cmd_rebuild()
{
    if [ "$1" == "" ] || [ "$2" == "" ]; then
        msg "Command must be in the format 'dev.sh rebuild [service-group] [container]'" error
        exit 1
    fi

    msg "Rebuilding container $1:$2 ..." heading

    # Fix for VirtualBox not dropping disk cache
    # See https://github.com/moby/moby/issues/18584
    # See https://www.virtualbox.org/ticket/9069
    sudo sh -c "echo 1 > /proc/sys/vm/drop_caches"

    # Rebuild container
    sudo docker-compose -f docker-compose.$1.yml stop $2
    sudo docker-compose -f docker-compose.$1.yml rm -f $2
    sudo docker-compose -f docker-compose.$1.yml build $2
    sudo docker-compose -f docker-compose.$1.yml up -d $2

    msg "Container $1:$2 rebuilt." success
}

#
# Clean everything
#
register_command "clean" "cmd_clean" "Deletes all containers and images and volumes. Everything."
function cmd_clean()
{
    cd /srv/env/docker

    msg "THIS IS GOING TO DELETE EVERYTHING FROM DOCKER!" alert
    sleep 2
    msg "A REBUILD TAKES A LONG TIME AND MAY DELETE STUFF!" alert
    sleep 2
    msg "YOU HAVE 30 SECONDS TO CANCEL THIS ACTION [Ctrl+C]" alert
    sleep 30;

    # Remove everything
    sudo docker stop
    sleep 5
    sudo docker system prune -a

    msg "All done. Everything has been removed." success
}

#
# Clean logs only, for runaway environments
#
register_command "clean-logs" "cmd_clean_logs" "Clears all log files"
function cmd_clean_logs()
{
    msg 'Clearing all docker log files ...' heading
    logSize=$(sudo find /var/lib/docker -path "*containers/*/*.log" -exec sudo du -sc {} + | awk '$2 == "total" {total += $1} END {print total}')
    msg "Log files currently consuming $logSize bytes. Continuing with clearing ..."
    sleep 2
    sudo truncate --size=0 $(sudo find /var/lib/docker -path "*containers/*/*.log")
    msg "Log files cleared." success
}

#
# Debug Start Shell
#
register_command "start-shell" "cmd_start_shell" "Start a container but using SHELL as the entrypoint"
function cmd_start_shell()
{
    if [ "$1" == "" ] || [ "$2" == "" ]; then
        msg "Command must be in the format 'dev.sh start-shell [service-group] [container]'" error
        exit 1
    fi

    sudo docker-compose -f docker-compose.$1.yml run --entrypoint=sh $2
}

#
# Direct Shell
#
register_command "shell" "cmd_shell" "Shell into a running container"
function cmd_shell()
{
    if [ "$1" == "" ] || [ "$2" == "" ]; then
        msg "Command must be in the format 'dev.sh shell [service-group] [container]'" error
        exit 1
    fi

    sudo docker-compose -f docker-compose.$1.yml exec $2 sh
}


#
# Display a pretty message
#
# Examples:
# msg "text" error
# msg "text" alert
# msg "text" success
# msg "text" heading
# msg "text"
#
function msg ()
{

    # Colors
    local C_MSG='\033[0;43;30m'     # black-on-yellow
    local C_SUCCESS='\033[0;42;30m'     # black-on-green
    local C_HEADING='\033[0;46;30m' # black-on-blue
    local C_ALERT='\033[0;41;30m'   # black-on-red
    local C_ERROR='\033[5;41;30m'   # black-on-red
    local C_NORM='\033[0m'          # reset

    # auto pad like a heading
    pad=1

    # Message is the first arg
    msg=$1

    # Pick style from second arg
    case "$2" in
        error*)
            printf "${C_ERROR}"
            msg="[ERROR] $msg"
            ;;
        alert*)
            printf "${C_ALERT}"
            msg="[ALERT] $msg"
            ;;
        success*)
            printf "${C_SUCCESS}"
            msg="[OK]    $msg"
            ;;
        heading*)
            printf "${C_HEADING}"
            msg="[INFO]  $msg"
            ;;
        *)
            pad=0
            printf ${C_MSG}
      esac

    # Base is 1 line
    msgs=( "$msg" )

    # Wrap with empty strings
    if [ "$pad" = 1 ]; then
        msgs=( " " "$msg" " " )
    fi

    # Each line
    for line_msg in "${msgs[@]}"
    do
        # Break line
        printf "\n "

        # Message
        printf " %s" "$line_msg"

        # Pad white space
        local padlength=$(tput cols)
        printf '%*.*s' $((padlength - ${#line_msg} - 10 )) $(printf '%0.1s' " "{1..200})
    done

    # Revert color
    printf "${C_NORM}\n\n"
}

# Start Main
cmd_main $@;
