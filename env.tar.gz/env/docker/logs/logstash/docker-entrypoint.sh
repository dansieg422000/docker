#!/bin/bash
echo "Starting logstash"
/usr/share/logstash/bin/logstash -f /usr/share/logstash/pipeline/logstash.conf --log.level=warning