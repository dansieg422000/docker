#!/bin/bash

# Docker Compose
# Start without rebuild

cd /srv/env/docker

# Start normally
sudo docker-compose -f docker-compose.app.yml up -d
sudo docker-compose -f docker-compose.docs.yml up -d
