#!/bin/bash

cd /srv/env/docker

# Stop and remove all containers, so whatever is rebuilt is what is used
sudo docker stop $(sudo docker ps -a -q) 2>&1 > /dev/null
sudo docker rm $(sudo docker ps -a -q) 2>&1 > /dev/null

# Pre-provision and create local base images
sudo docker build -t elmo-base               ./base/elmo-base
sudo docker build -t elmo-base-service       ./base/elmo-base-service
sudo docker build -t elmo-base-service-jre8  ./base/elmo-base-service-jre8

# Execute Compose build
sudo docker-compose -f docker-compose.app.yml build
sudo docker-compose -f docker-compose.docs.yml build
sudo docker-compose -f docker-compose.logging.yml build